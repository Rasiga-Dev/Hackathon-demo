

// import React, { useState, useEffect } from 'react';
// import { Link, useNavigate } from 'react-router-dom';
// import { Users, LogOut, CheckCircle, XCircle, Menu } from 'lucide-react';
// import axios from 'axios';
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

// interface Evaluator {
//   _id: string;
//   name: string;
//   email: string;
//   institution: string;
//   expertise: string[];
//   status: 'pending' | 'approved' | 'rejected';
// }

// interface School {
//   _id: string;
//   School_Name: string;
//   UDISE_Code: string;
//   Email_ID: string;
//   District: string;
//   Address: string;
//   Office_Mobile: number;
//   status: string;
// }


// interface EvaluatorList {
//   _id: string;
//   username: string;
//   name: string;
//   evaluationStage: string;
//   email: string;
//   institution: string;
//   expertise: string[];
//   status: 'pending' | 'approved' | 'rejected';
// }




// export default function AdminDashboard() {
//   const navigate = useNavigate();
//   const [selectedMenu, setSelectedMenu] = useState('');
//   const [evaluatorList, setEvaluatorList] = useState<EvaluatorList[]>([]);

//   const [evaluators, setEvaluators] = useState<Evaluator[]>([]);

//   const [isLoading, setIsLoading] = useState(true);

//   const [drawerOpen, setDrawerOpen] = useState(true);
//   const [schools, setSchools] = useState<School[]>([]);

//   useEffect(() => {
//     const adminToken = localStorage.getItem('adminToken');
//     if (!adminToken) {
//       navigate('/admin-login');
//       return;
//     }
//     fetchEvaluators();
//   }, [navigate]);

//   useEffect(() => {
//     if (selectedMenu === 'schools') {
//       fetchSchools();
//     }
//     if (selectedMenu === 'eval-list') {
//       fetchEvaluatorsList();
//     }
//   }, [selectedMenu]);

//   const fetchSchools = async () => {
//     try {
//       const token = localStorage.getItem('adminToken');
//       const res = await axios.get('http://localhost:11129/api/schools/get-registered-schools', {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setSchools(res.data);
//     } catch (err) {
//       console.error('Error fetching schools', err);
//       toast.error('Failed to load school details');
//     }
//   };

//   const fetchEvaluators = async () => {
//     const token = localStorage.getItem('adminToken');
//     try {
//       const response = await axios.get('http://localhost:11129/api/evaluator/pending', {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setEvaluators(response.data);
//     } catch (error) {
//       console.error('Error fetching evaluators:', error);
//       toast.error('Failed to fetch evaluators');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const fetchEvaluatorsList = async () => {
//     try {
//       const res = await axios.get('http://localhost:11129/api/admin/get-evaluators');
//       setEvaluatorList(res.data);
//     } catch (err) {
//       console.error('Error fetching evaluators:', err);
//     }
//   };

//   const handleStatusChange = async (evaluatorId: string, status: 'approved' | 'rejected') => {
//     try {
//       const endpoint = `http://localhost:11129/api/evaluator/${status}/${evaluatorId}`;
//       await axios.put(endpoint, {}, {
//         headers: {
//           Authorization: `Bearer ${localStorage.getItem('adminToken')}`,
//         },
//       });
//       toast.success(`Evaluator ${status} successfully`);
//       fetchEvaluators();
//     } catch (error) {
//       console.error(`Error ${status} evaluator:`, error);
//       toast.error(`Failed to ${status} evaluator`);
//     }
//   };

//   const handleLogout = () => {
//     localStorage.removeItem('adminToken');
//     navigate('/admin-login');
//   };

//   return (
//     <div className="flex min-h-screen bg-gray-100">
//       {/* Sidebar */}
//       <div className={`bg-white w-64 shadow-md transition-transform ${drawerOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
//         <div className="p-4 border-b flex justify-between items-center">
//           <h2 className="text-xl font-semibold text-gray-800">Admin Panel</h2>
//           <button onClick={() => setDrawerOpen(!drawerOpen)} className="md:hidden">
//             <Menu className="h-6 w-6 text-gray-600" />
//           </button>
//         </div>
//         <ul className="p-4 space-y-2">
//           {/* Main Evaluators Menu with Submenu */}
//           <li>
//             <button
//               onClick={() => setSelectedMenu(selectedMenu === 'evaluators' ? '' : 'evaluators')}
//               className={`w-full text-left px-4 py-2 rounded ${selectedMenu === 'evaluators'
//                 ? 'bg-red-100 text-red-600 font-semibold'
//                 : 'text-gray-700 hover:bg-gray-100'
//                 }`}
//             >
//               Evaluators
//             </button>


//           </li>

//           {/* Schools menu */}
//           <li>
//             <button
//               className={`w-full text-left px-4 py-2 rounded ${selectedMenu === 'schools'
//                 ? 'bg-red-100 text-red-600 font-semibold'
//                 : 'text-gray-700 hover:bg-gray-100'
//                 }`}
//               onClick={() => setSelectedMenu('schools')}
//             >
//               School Details
//             </button>
//           </li>

//           {/* Evaluators Details (as separate main item) */}
//           <li>
//             <button
//               className={`w-full text-left px-4 py-2 rounded ${selectedMenu === 'eval' ? 'bg-red-100 text-red-600 font-semibold' : 'text-gray-700 hover:bg-gray-100'
//                 }`}
//               onClick={() => setSelectedMenu('eval')}
//             >
//               Evaluators Details
//             </button>
//             {selectedMenu === 'eval' && (
//               <ul className="pl-6 mt-1 space-y-1">
//                 <li>
//                   <button
//                     className="w-full text-left px-4 py-1 rounded text-gray-600 hover:bg-gray-100 text-sm"
//                     onClick={() => setSelectedMenu('eval-list')}
//                   >
//                     Evaluator List
//                   </button>
//                 </li>
//                 <li>
//                   <button
//                     className="w-full text-left px-4 py-1 rounded text-gray-600 hover:bg-gray-100 text-sm"
//                     onClick={() => setSelectedMenu('eval-assign')}
//                   >
//                     Assign Projects
//                   </button>
//                 </li>
//               </ul>
//             )}
//           </li>

//           {/* Logout */}
//           <li>
//             <button
//               onClick={handleLogout}
//               className="w-full text-left px-4 py-2 rounded text-gray-700 hover:bg-gray-100"
//             >
//               <div className="flex items-center gap-2">
//                 <LogOut className="h-5 w-5" /> Logout
//               </div>
//             </button>
//           </li>
//         </ul>

//       </div>

//       {/* Main Content */}
//       <div className="flex-1 p-6">
//         <div className="flex items-center justify-between mb-6">
//           <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
//           <button onClick={() => setDrawerOpen(!drawerOpen)} className="md:hidden text-gray-600">
//             <Menu className="h-6 w-6" />
//           </button>
//         </div>

//         {/* Evaluator Section */}
//         {selectedMenu === 'evaluators' && (
//           <div className="bg-white rounded-lg shadow p-6">
//             <h2 className="text-xl font-bold text-gray-900 mb-4">Evaluator Applications</h2>
//             {isLoading ? (
//               <div className="text-center py-4">Loading...</div>
//             ) : evaluators.length === 0 ? (
//               <div className="text-center py-4 text-gray-500">No pending applications</div>
//             ) : (
//               <div className="overflow-x-auto">
//                 <table className="min-w-full divide-y divide-gray-200">
//                   <thead className="bg-gray-50">
//                     <tr>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Institution</th>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expertise</th>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
//                       <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
//                     </tr>
//                   </thead>
//                   <tbody className="bg-white divide-y divide-gray-200">
//                     {evaluators.map((evaluator) => (
//                       <tr key={evaluator._id}>
//                         <td className="px-6 py-4">{evaluator.name}</td>
//                         <td className="px-6 py-4">{evaluator.email}</td>
//                         <td className="px-6 py-4">{evaluator.institution}</td>
//                         <td className="px-6 py-4">{evaluator.expertise.join(', ')}</td>
//                         <td className="px-6 py-4">
//                           <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${evaluator.status === 'approved' ? 'bg-green-100 text-green-800' :
//                             evaluator.status === 'rejected' ? 'bg-red-100 text-red-800' :
//                               'bg-yellow-100 text-yellow-800'
//                             }`}>
//                             {evaluator.status}
//                           </span>
//                         </td>
//                         <td className="px-6 py-4">
//                           <div className="flex space-x-2">
//                             <button
//                               onClick={() => handleStatusChange(evaluator._id, 'approved')}
//                               className="text-green-600 hover:text-green-900"
//                             >
//                               <CheckCircle className="h-5 w-5" />
//                             </button>
//                             <button
//                               onClick={() => handleStatusChange(evaluator._id, 'rejected')}
//                               className="text-red-600 hover:text-red-900"
//                             >
//                               <XCircle className="h-5 w-5" />
//                             </button>
//                           </div>
//                         </td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             )}
//           </div>
//         )}

//         {/* Schools Section */}
//         {selectedMenu === 'schools' && (
//           <div className="bg-white rounded-lg shadow p-6">
//             <h2 className="text-xl font-bold text-gray-900 mb-4">Registered Schools</h2>
//             {schools.length === 0 ? (
//               <div className="text-center py-4 text-gray-500">No registered schools found</div>
//             ) : (
//               <div className="overflow-x-auto">
//                 <table className="min-w-full divide-y divide-gray-200 table-auto">
//                   <thead className="bg-gray-50">
//                     <tr>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">UDISE Code</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">School Name</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">District</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mobile</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
//                       <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">View Details</th>

//                     </tr>
//                   </thead>
//                   <tbody className="bg-white divide-y divide-gray-200">
//                     {schools.map((school) => (
//                       <tr key={school._id}>
//                         <td className="px-4 py-2">{school.UDISE_Code}</td>
//                         <td className="px-4 py-2">{school.School_Name}</td>
//                         <td className="px-4 py-2">{school.Email_ID}</td>
//                         <td className="px-4 py-2">{school.District}</td>
//                         <td className="px-4 py-2">{school.Office_Mobile}</td>
//                         <td className="px-4 py-2 capitalize"> <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${school.status === 'registered'
//                           ? 'bg-green-100 text-green-800'
//                           : 'bg-yellow-100 text-yellow-800'
//                           }`}>
//                           {school.status}
//                         </span></td>
//                         <td className="px-4 py-2 text-blue-500">
//                           <Link to={`/school/${school._id}`}>View Details</Link>
//                         </td>


//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             )}
//           </div>
//         )}

//         {/* Evaluator List Section */}
//         {selectedMenu === 'eval-list' && (
//           <div className="p-4">
//             <h2 className="text-lg font-semibold mb-4">Evaluator List</h2>

//             {evaluatorList.length === 0 ? (
//               <p>No evaluators found.</p>
//             ) : (
//               <div className="overflow-x-auto">
//                 <table className="min-w-full table-auto border border-gray-200 text-sm">
//                   <thead className="bg-gray-100 text-left">
//                     <tr>
//                       <th className="px-4 py-2 border">Name</th>
//                       <th className="px-4 py-2 border">Username</th>
//                       <th className="px-4 py-2 border">Email</th>
                 
//                       <th className="px-4 py-2 border">Stage</th>
//                       <th className="px-4 py-2 border">Expertise</th>
//                       <th className="px-4 py-2 border">Status</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {evaluatorList.map((ev) => (
//                       <tr key={ev._id} className="hover:bg-gray-50">
//                         <td className="px-4 py-2 border">{ev.name}</td>
//                         <td className="px-4 py-2 border">{ev.username}</td>
//                         <td className="px-4 py-2 border">{ev.email}</td>
                    
//                         <td className="px-4 py-2 border">{ev.evaluationStage}</td>
//                         <td className="px-4 py-2 border">{ev.expertise.join(', ')}</td>
//                         <td className="px-4 py-2 border capitalize">{ev.status}</td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             )}
//           </div>
//         )}


//       </div>

//       <ToastContainer />
//     </div>
//   );
// }


import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Users, LogOut, CheckCircle, XCircle, Menu, LayoutDashboard, School, UserCheck, Settings } from 'lucide-react';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

interface Evaluator {
  _id: string;
  name: string;
  email: string;
  institution: string;
  expertise: string[];
  status: 'pending' | 'approved' | 'rejected';
}

interface School {
  _id: string;
  School_Name: string;
  UDISE_Code: string;
  Email_ID: string;
  District: string;
  Address: string;
  Office_Mobile: number;
  status: string;
}

interface EvaluatorList {
  _id: string;
  username: string;
  name: string;
  evaluationStage: string;
  email: string;
  institution: string;
  expertise: string[];
  status: 'pending' | 'approved' | 'rejected';
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [selectedMenu, setSelectedMenu] = useState('dashboard');
  const [evaluatorList, setEvaluatorList] = useState<EvaluatorList[]>([]);
  const [evaluators, setEvaluators] = useState<Evaluator[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [schools, setSchools] = useState<School[]>([]);

  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      navigate('/admin-login');
      return;
    }
    fetchEvaluators();
  }, [navigate]);

  useEffect(() => {
    if (selectedMenu === 'schools') {
      fetchSchools();
    }
    if (selectedMenu === 'eval-list') {
      fetchEvaluatorsList();
    }
  }, [selectedMenu]);

  const fetchSchools = async () => {
    try {
      const token = localStorage.getItem('adminToken');
      const res = await axios.get('http://localhost:11129/api/admin/get-registered-schools', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSchools(res.data);
    } catch (err) {
      console.error('Error fetching schools', err);
      toast.error('Failed to load school details');
    }
  };

  const fetchEvaluators = async () => {
    const token = localStorage.getItem('adminToken');
    try {
      const response = await axios.get('http://localhost:11129/api/evaluator/pending', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEvaluators(response.data);
    } catch (error) {
      console.error('Error fetching evaluators:', error);
      toast.error('Failed to fetch evaluators');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchEvaluatorsList = async () => {
    try {
      const res = await axios.get('http://localhost:11129/api/admin/get-evaluators');
      setEvaluatorList(res.data);
    } catch (err) {
      console.error('Error fetching evaluators:', err);
    }
  };

  const handleStatusChange = async (evaluatorId: string, status: 'approved' | 'rejected') => {
    try {
      const endpoint = `http://localhost:11129/api/evaluator/${status}/${evaluatorId}`;
      await axios.put(endpoint, {}, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('adminToken')}`,
        },
      });
      toast.success(`Evaluator ${status} successfully`);
      fetchEvaluators();
    } catch (error) {
      console.error(`Error ${status} evaluator:`, error);
      toast.error(`Failed to ${status} evaluator`);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    navigate('/admin-login');
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'evaluators', label: 'Pending Evaluators', icon: Users },
    { id: 'schools', label: 'Schools', icon: School },
    { id: 'eval-list', label: 'Evaluator List', icon: UserCheck },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className={`bg-white w-64 shadow-lg transition-transform ${drawerOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed h-full`}>
        <div className="p-4 border-b flex justify-between items-center bg-red-800 text-white">
          <h2 className="text-xl font-semibold">Admin Panel</h2>
          <button onClick={() => setDrawerOpen(!drawerOpen)} className="md:hidden">
            <Menu className="h-6 w-6" />
          </button>
        </div>
        <nav className="p-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setSelectedMenu(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                selectedMenu === item.id
                  ? 'bg-red-100 text-red-800'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.label}</span>
            </button>
          ))}
          <button
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-600 hover:bg-gray-100 mt-8"
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 md:ml-64 p-8">
        <div className="max-w-7xl mx-auto">
          {/* Dashboard Overview */}
          {selectedMenu === 'dashboard' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-2">Total Schools</h3>
                <p className="text-3xl font-bold text-red-800">{schools.length}</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-2">Pending Evaluators</h3>
                <p className="text-3xl font-bold text-red-800">{evaluators.length}</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-2">Total Evaluators</h3>
                <p className="text-3xl font-bold text-red-800">{evaluatorList.length}</p>
              </div>
            </div>
          )}

          {/* Pending Evaluators Section */}
          {selectedMenu === 'evaluators' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Pending Evaluator Applications</h2>
              {isLoading ? (
                <div className="text-center py-4">Loading...</div>
              ) : evaluators.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No pending applications</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Institution</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expertise</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {evaluators.map((evaluator) => (
                        <tr key={evaluator._id} className="hover:bg-gray-50">
                          <td className="px-6 py-4">{evaluator.name}</td>
                          <td className="px-6 py-4">{evaluator.email}</td>
                          <td className="px-6 py-4">{evaluator.institution}</td>
                          <td className="px-6 py-4">{evaluator.expertise.join(', ')}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              evaluator.status === 'approved'
                                ? 'bg-green-100 text-green-800'
                                : evaluator.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {evaluator.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex space-x-2">
                              <button
                                onClick={() => handleStatusChange(evaluator._id, 'approved')}
                                className="text-green-600 hover:text-green-900"
                              >
                                <CheckCircle className="h-5 w-5" />
                              </button>
                              <button
                                onClick={() => handleStatusChange(evaluator._id, 'rejected')}
                                className="text-red-600 hover:text-red-900"
                              >
                                <XCircle className="h-5 w-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Schools Section */}
          {selectedMenu === 'schools' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Registered Schools</h2>
              {schools.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No registered schools found</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">UDISE Code</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">School Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">District</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mobile</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {schools.map((school) => (
                        <tr key={school._id} className="hover:bg-gray-50">
                          <td className="px-4 py-2">{school.UDISE_Code}</td>
                          <td className="px-4 py-2">{school.School_Name}</td>
                          <td className="px-4 py-2">{school.Email_ID}</td>
                          <td className="px-4 py-2">{school.District}</td>
                          <td className="px-4 py-2">{school.Office_Mobile}</td>
                          <td className="px-4 py-2">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              school.status === 'registered'
                                ? 'bg-green-100 text-green-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {school.status}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-blue-600 hover:text-blue-800">
                            <Link to={`/school/${school._id}`}>View Details</Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Evaluator List Section */}
          {selectedMenu === 'eval-list' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Evaluator List</h2>
              {evaluatorList.length === 0 ? (
                <div className="text-center py-4 text-gray-500">No evaluators found</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Username</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stage</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expertise</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {evaluatorList.map((ev) => (
                        <tr key={ev._id} className="hover:bg-gray-50">
                          <td className="px-4 py-2">{ev.name}</td>
                          <td className="px-4 py-2">{ev.username}</td>
                          <td className="px-4 py-2">{ev.email}</td>
                          <td className="px-4 py-2">{ev.evaluationStage}</td>
                          <td className="px-4 py-2">{ev.expertise.join(', ')}</td>
                          <td className="px-4 py-2">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              ev.status === 'approved'
                                ? 'bg-green-100 text-green-800'
                                : ev.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {ev.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Settings Section */}
          {selectedMenu === 'settings' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Settings</h2>
              <p className="text-gray-600">Admin settings and configuration options will be available here.</p>
            </div>
          )}
        </div>
      </div>

      <ToastContainer position="top-center" autoClose={3000} hideProgressBar />
    </div>
  );
}