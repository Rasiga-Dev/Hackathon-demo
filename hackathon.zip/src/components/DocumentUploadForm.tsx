

import React, { useState, useEffect } from 'react';
import { Upload, AlertCircle } from 'lucide-react';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

interface DocumentUploadFormProps {
  onNext: (data: { file: File | null }) => void;
  initialFile?: File | null; // Optional prop to accept an initial file
}

const DocumentUploadForm: React.FC<DocumentUploadFormProps> = ({ onNext, initialFile }) => {
  const [file, setFile] = useState<File | null>(initialFile || null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (initialFile) {
      setFile(initialFile);
    }
  }, [initialFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (!selectedFile) {
      setError('Please select a file');
      setFile(null);
      toast.error('Please select a file');
      return;
    }

    if (!selectedFile.name.endsWith('.pptx')) {
      setError('Only .pptx files are allowed');
      setFile(null);
      toast.error('Only .pptx files are allowed');
      return;
    }

    setError('');
    setFile(selectedFile);
    toast.success('File selected successfully!');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a file');
      toast.error('Please select a file');
      return;
    }

    toast.success('File uploaded successfully!');
    onNext({ file });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="w-full p-8 border-2 border-dashed border-gray-300 rounded-lg text-center">
        <input
          type="file"
          accept=".pptx"
          onChange={handleFileChange}
          className="hidden"
          id="file-upload"
        />
        <label
          htmlFor="file-upload"
          className="cursor-pointer flex flex-col items-center justify-center space-y-4"
        >
          <Upload className="w-12 h-12 text-gray-400" />
          <div className="space-y-2">
            <p className="text-lg font-medium text-gray-700">
              Upload your presentation
            </p>
            <p className="text-sm text-gray-500">
              Only .pptx files are allowed
            </p>
          </div>
        </label>
      </div>

      {error && (
        <div className="flex items-center space-x-2 text-red-600">
          <AlertCircle className="w-5 h-5" />
          <span>{error}</span>
        </div>
      )}

      {file && (
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-green-800">
            Selected file: {file.name}
          </p>
        </div>
      )}

      <div className="flex justify-end">
        <button
          type="submit"
          className="px-6 py-3 bg-red-800 text-white rounded-md hover:bg-red-900 transition-colors duration-300"
          disabled={!file}
        >
          Save & Continue
        </button>
      </div>
      
      <ToastContainer position="top-center" autoClose={3000} hideProgressBar />
    </form>
  );
};

export default DocumentUploadForm;
