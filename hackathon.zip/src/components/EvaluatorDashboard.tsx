

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

interface Project {
    _id: string;
    schoolId: string;
    schoolName: string;
    projectDetails: {
        title: string;
        description: string;
    };
    documentFile: {
        filename: string;
        contentType: string;
        data: {
            data: number[];
        };
    };
    evaluationStatus: string;
    statusReason?: string;
    tempStatus?: string;
    tempReason?: string;
}

export default function EvaluatorDashboard() {
    const navigate = useNavigate();
    const [projects, setProjects] = useState<Project[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const token = localStorage.getItem('evaluatorToken');
        if (!token) {
            navigate('/evaluator-login');
            return;
        }
        fetchAssignedProjects();
    }, [navigate]);

    const fetchAssignedProjects = async () => {
        try {
            const token = localStorage.getItem('evaluatorToken');
            const response = await axios.get('http://localhost:11129/api/evaluator/assigned-projects', {
                headers: { Authorization: `Bearer ${token}` }
            });

            // Add temporary status/reason fields
            const enrichedProjects = response.data.map((project: Project) => ({
                ...project,
                tempStatus: '',
                tempReason: '',
            }));

            setProjects(enrichedProjects);
        } catch (error) {
            console.error('Error fetching projects:', error);
            toast.error('Failed to fetch assigned projects');
        } finally {
            setIsLoading(false);
        }
    };

   

    const downloadDocument = (project: Project) => {
  const bufferData = project.documentFile.data?.data || project.documentFile.data;
  const byteArray = new Uint8Array(bufferData);
  const blob = new Blob([byteArray], { type: project.documentFile.contentType });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = project.documentFile.filename || 'document.pptx';
  document.body.appendChild(link); // Ensure it's in the DOM
  link.click();
  document.body.removeChild(link);
};


    const handleStatusChange = (index: number, value: string) => {
        const updatedProjects = [...projects];
        updatedProjects[index].tempStatus = value;
        setProjects(updatedProjects);
    };

    const handleReasonChange = (index: number, value: string) => {
        const updatedProjects = [...projects];
        updatedProjects[index].tempReason = value;
        setProjects(updatedProjects);
    };

   

    const handleSubmitEvaluation = async (projectId: string, status: string, reason: string) => {
        if (!status || !reason) {
            toast.warning('Please select status and enter reason');
            return;
        }
    
        try {
            const token = localStorage.getItem('evaluatorToken');
            await axios.post(`http://localhost:11129/api/evaluator/evaluate/${projectId}`, {
                status,
                reason,
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });
    
            toast.success('Evaluation submitted');
    
            // ✅ Just remove it locally — don't fetch all again
            setProjects((prev) => prev.filter((p) => String(p._id) !== String(projectId)));
    
        } catch (error) {
            toast.error('Evaluation failed');
        }
    };
    



    return (
        <div className="p-6">
            <ToastContainer />
            <h2 className="text-2xl font-bold mb-4">Evaluator Dashboard</h2>
            {isLoading ? (
                <p>Loading...</p>
            ) : (
                <table className="w-full border border-gray-300 text-sm">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="p-2 border">School ID</th>
                            <th className="p-2 border">Project ID</th>
                            <th className="p-2 border">Title</th>
                            <th className="p-2 border">Description</th>
                            <th className="p-2 border">Document</th>
                            <th className="p-2 border">Status</th>
                            <th className="p-2 border">Status Reason</th>
                            <th className="p-2 border">Submit</th>
                        </tr>
                    </thead>
                    <tbody>
                        {projects.map((project, index) => (
                            <tr key={project._id} className="border-t">
                                <td className="p-2 border">{project.schoolId}</td>
                                <td className="p-2 border">{project._id}</td>
                                <td className="p-2 border">{project.projectDetails.title}</td>
                                <td className="p-2 border">{project.projectDetails.description}</td>
                                <td className="p-2 border">
                                    <button
                                        onClick={() => downloadDocument(project)}
                                        className="text-blue-600 underline"
                                    >
                                        Download
                                    </button>
                                </td>
                                <td className="p-2 border">
                                    <select
                                        value={project.tempStatus}
                                        onChange={(e) => handleStatusChange(index, e.target.value)}
                                        className="border px-2 py-1"
                                    >
                                        <option value="">-- Select --</option>
                                        <option value="accepted">Accepted</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </td>
                                <td className="p-2 border">
                                    <textarea
                                        value={project.tempReason}
                                        onChange={(e) => handleReasonChange(index, e.target.value)}
                                        className="w-full border px-2 py-1"
                                        placeholder="Enter reason"
                                        rows={2}
                                    />
                                </td>
                                <td className="p-2 border">
                                    <button
                                        onClick={() =>
                                            handleSubmitEvaluation(project._id, project.tempStatus || '', project.tempReason || '')
                                        }
                                        className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                                    >
                                        Submit
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {projects.length === 0 && (
                            <tr>
                                <td colSpan={8} className="text-center py-4">
                                    No assigned projects found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            )}
        </div>
    );
}
