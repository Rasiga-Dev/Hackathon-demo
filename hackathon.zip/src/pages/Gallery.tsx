


import React, { useState } from 'react';
import { motion } from 'framer-motion';

export function Gallery() {
  const [selectedImage, setSelectedImage] = useState(null);

  const galleryItems = [
    {
      image: "image-2.jpg",
      title: "Innovation Hub",
      description: "Where ideas come to life",
      details: "In this space, we brainstorm, prototype, and build innovative solutions that have a real-world impact."
    },
    {
      image: "image-1.jpg",
      title: "Collaboration Space",
      description: "Teams working together",
      details: "Our collaboration space fosters creativity and teamwork, bringing diverse minds together to solve complex challenges."
    },
    {
      image: "image-4.jpg",
      title: "Presentation Time",
      description: "Showcasing solutions",
      details: "Teams present their hard work and innovative ideas to an audience of judges and peers."
    }
  ];

  const handleImageClick = (item) => {
    setSelectedImage(item);
  };

  const closeModal = () => {
    setSelectedImage(null);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="space-y-16 sm:px-6 lg:px-8 max-w-8xl mx-auto"
    >


      {/* Featured Gallery Section */}
      <section className="bg-white p-6 sm:p-10 rounded-3xl shadow-2xl">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center text-red-800 mb-4 drop-shadow">
          Featured Gallery
        </h2>
        <p className="text-lg sm:text-xl text-gray-600 text-center mb-10">
          A sneak peek into the best moments of our Hackathon. Check out the creativity and teamwork in action!
        </p>

        <div className="space-y-10">
          {galleryItems.map((item, index) => (
            <motion.div
              key={index}
              className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-gray-50 rounded-2xl shadow-lg overflow-hidden cursor-pointer hover:scale-[1.02] transition-transform duration-500"
              whileHover={{ scale: 1.02 }}
              onClick={() => handleImageClick(item)}
            >
              {/* Left Column: Image */}
              <div className="w-full h-full">
                <img
                  src={item.image}
                  loading="lazy"
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Right Column: Title & Description */}
              <div className="p-6 md:p-8">
                <h3 className="text-2xl md:text-3xl font-semibold text-brown-700 mb-3">{item.title}</h3>
                <p className="text-gray-600 text-base md:text-lg">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>


     

      {/* Gallery Categories Section */}
      <section className="p-6 sm:p-10 rounded-3xl shadow-2xl">
        <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-8">Gallery Categories</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {["Innovation", "Teamwork", "Event Highlights", "Networking", "Workshops", "Closing Ceremony"].map((category, index) => (
            <div
              key={index}
              className="bg-white text-center rounded-2xl p-6 shadow-xl hover:scale-105 transition-transform duration-500"
            >
              <h3 className="text-2xl font-bold text-brown-700 mb-2">{category}</h3>
              <p className="text-gray-600">Click to view images related to {category}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-white p-6 sm:p-10 rounded-3xl shadow-2xl">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-gray-900 mb-10">What Participants Say</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              name: "John Doe",
              testimonial:
                "This was an amazing experience! The networking and learning were top-notch. Can't wait for the next one!"
            },
            {
              name: "Jane Smith",
              testimonial:
                "The Hackathon was a great platform to collaborate and innovate with like-minded individuals."
            },
            {
              name: "Mark Williams",
              testimonial:
                "The workshops were extremely insightful and helped us fine-tune our ideas. Thank you, EDII!"
            }
          ].map((item, index) => (
            <div
              key={index}
              className="bg-gray-100 p-6 rounded-2xl shadow-md hover:shadow-xl transition duration-500"
            >
              <p className="text-lg text-gray-700 mb-2">"{item.testimonial}"</p>
              <p className="text-sm text-gray-500 font-semibold">- {item.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Social Media Feeds */}
      <section className="bg-gradient-to-r from-red-600 to-brown-500 p-6 sm:p-10 rounded-3xl shadow-2xl">
        <h2 className="text-3xl sm:text-4xl font-bold text-white text-center mb-8">Follow Us on Social Media</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">Instagram</h3>
            <p className="text-gray-600">#EDIIHackathon</p>
            <div className="mt-4">[Instagram Feed]</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg text-center">
            <h3 className="text-2xl font-semibold text-gray-800 mb-2">Twitter</h3>
            <p className="text-gray-600">#EDIIHackathon</p>
            <div className="mt-4">[Twitter Feed]</div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}
