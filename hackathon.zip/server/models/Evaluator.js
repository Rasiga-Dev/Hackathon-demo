import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const evaluatorSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  evaluationStage: {
    type: String,
     enum: ['stage1', 'stage2','stage3'], // allowed values
    required: true
  },
  expertise: [String],
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  evaluatedProjects: [{
    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School.submissions'
    },
    score: Number,
    feedback: String,
    evaluatedAt: Date
  }]
}, {
  timestamps: true
});


// Hash password before saving
evaluatorSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

const Evaluator = mongoose.model('Evaluator', evaluatorSchema);
export default Evaluator;