import express from 'express';
import School from '../models/School.js';
import bcrypt from 'bcrypt';
import multer from 'multer'; // For handling file uploads
import jwt from 'jsonwebtoken';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();



// Configure multer for file uploads
const storage = multer.memoryStorage();


// Get all schools
router.get('/schools', async (req, res) => {
  try {
    const schools = await School.find(); // Fetch all school data
    res.json(schools); // Send the data as JSON response
  } catch (error) {
    res.status(500).send({ error: 'Failed to fetch school data' });
  }
});

// Get school by ID
router.get('/schools/:id', async (req, res) => {
  try {
    const school = await School.findById(req.params.id); // Fetch school by ID
    if (!school) {
      return res.status(404).send({ error: 'School not found' });
    }
    res.json(school);
  } catch (error) {
    res.status(500).send({ error: 'Failed to fetch school data' });
  }
});




// This should be in your routes file (e.g., routes.js or api.js)
router.get('/udise/:code', async (req, res) => {
  try {
    const udiseCode = Number(req.params.code); // Convert to number
    const school = await School.findOne({ UDISE_Code: udiseCode });

    if (!school) {
      return res.status(404).json({ error: 'UDISE Code not found' });
    }

    // Only send the required fields
    res.json({
      School_Name: school.School_Name,
      Email_ID: school.Email_ID,
      District: school.District,
    });
  } catch (error) {
    res.status(500).json({ error: 'Error fetching school by UDISE Code' });
  }
});



router.post('/login', async (req, res) => {
  const { udiseCode, password } = req.body;

  try {
    const school = await School.findOne({ UDISE_Code: parseInt(udiseCode) });

    if (!school) return res.status(404).json({ message: 'School not found' });

    const isMatch = await bcrypt.compare(password, school.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid password' });

    if (school.status !== 'registered') {
      return res.status(403).json({ message: 'Please complete registration first' });
    }

    // Generate a JWT token after successful login
    const token = jwt.sign(
      { udiseCode: school.UDISE_Code, schoolId: school._id },
      process.env.JWT_SECRET || 'vosa', // Secret for JWT
      { expiresIn: '1h' } // Token expiration time
    );

    // Respond with the token and school data
    res.status(200).json({
      message: 'Login successful',
      token, // Return the token
      school: {
        name: school.School_Name,
        udiseCode: school.UDISE_Code,
        district: school.District,
        email: school.Email_ID,
        Latitute: school.Latitute,     // ✅ Include this
        longitude: school.Longitude
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});



router.post('/register', async (req, res) => {
  try {
    const { udiseCode, password } = req.body;
    const school = await School.findOne({ UDISE_Code: parseInt(udiseCode) });

    if (!school) return res.status(404).json({ message: 'School not found' });

    if (school.status === 'registered') {
      return res.status(400).json({ message: 'School already registered.Please login...' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    school.password = hashedPassword;
    school.status = 'registered';
    await school.save();

    res.status(200).json({ message: 'Registered successfully' });
  } catch (err) {
    console.error('Error in register route:', err);
    res.status(500).json({ message: 'Server error' });
  }
});











const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const { fieldname, mimetype } = file;

    // Check based on field name
    if (fieldname === 'documentFile') {
      if (mimetype === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type for documentFile. Only .pptx is allowed.'));
      }
    } else if (fieldname === 'paymentScreenshot') {
      if (['image/png', 'image/jpeg', 'image/jpg'].includes(mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type for paymentScreenshot. Only .png, .jpg, and .jpeg are allowed.'));
      }
    } else {
      cb(new Error('Unexpected field.'));
    }
  }
});








router.post('/submit-idea', upload.fields([
  { name: 'documentFile', maxCount: 1 },
  { name: 'paymentScreenshot', maxCount: 1 }
]), async (req, res) => {


  try {
    const { udiseCode, projectDetails, studentDetails, bmcDetails, transactionId } = req.body;
    const documentFile = req.files?.documentFile?.[0] || null;
    const paymentScreenshot = req.files?.paymentScreenshot?.[0] || null;


    console.log('Request body:', req.body);

    const school = await School.findOne({ UDISE_Code: udiseCode });

    if (!school) {
      return res.status(404).json({ message: 'School not found with the provided UDISE code.' });
    }

    let parsedProjectDetails = {};
    let parsedStudentDetails = [];
    let parsedBmcDetails = {};

    try {
      parsedProjectDetails = projectDetails ? JSON.parse(projectDetails) : {};
      parsedStudentDetails = studentDetails ? JSON.parse(studentDetails) : [];
      parsedBmcDetails = bmcDetails ? JSON.parse(bmcDetails) : {};
    } catch (error) {
      console.error('JSON parsing error:', error);
      return res.status(400).json({ message: 'Invalid data format' });
    }

    console.log('Parsed Project Details:', parsedProjectDetails); // Add this log

    // Save file buffer in MongoDB
    const newSubmission = {
      projectDetails: {
        title: parsedProjectDetails.ideaTitle,
        description: parsedProjectDetails.ideaDescription,
        teamSize: parsedProjectDetails.teamSize
      },
      studentDetails: parsedStudentDetails,
      bmcDetails: parsedBmcDetails,
      documentFile: documentFile ? {
        filename: documentFile.originalname,
        contentType: documentFile.mimetype,
        data: documentFile.buffer
      } : null,

      paymentScreenshot: paymentScreenshot ? {
        filename: paymentScreenshot.originalname,
        contentType: paymentScreenshot.mimetype,
        data: paymentScreenshot.buffer
      } : null,

      transactionId: transactionId || '',
      paymentStatus: 'successful',
      submittedAt: new Date(),
      evaluationStatus: 'pending'
    };

    console.log(newSubmission,"newSubmission")
    school.submissions.push(newSubmission);

    await school.save();

    res.status(200).json({ message: 'Idea submitted successfully!' });
  } catch (error) {
    console.error('Error submitting idea:', error);
    res.status(500).json({ message: 'Failed to submit the idea. Please try again later.' });
  }
});






router.get('/dashboard', authenticateToken, async (req, res) => {
  try {
    const school = await School.findById(req.user.schoolId);
    if (!school) {
      return res.status(404).json({ message: 'School not found' });
    }

    // Calculate dashboard metrics
    const totalProjects = school.submissions?.length || 0;
    const guideTeachers = school.guideTeachers?.length || 0;

    // Calculate total students from all submissions
    const studentsCount = school.submissions?.reduce((total, submission) => {
      return total + (submission.studentDetails?.length || 0);
    }, 0) || 0;

    // Return dashboard data
    res.status(200).json({
      totalProjects,
      guideTeachers,
      submittedIdeas: totalProjects, // Same as totalProjects for now
      studentsCount
    });
  } catch (err) {
    console.error('Error fetching dashboard data:', err);
    res.status(500).json({ message: 'Error fetching dashboard data' });
  }
});




//get all schools




// get school particular

router.get('/:id', async (req, res) => {
  try {
    const school = await School.findById(req.params.id);
    if (!school) return res.status(404).json({ message: 'School not found' });
    res.json(school);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
});



router.get('/schoolData', async (req, res) => {
  try {
    // Fetch all school data, including guide teachers and other fields
    const schoolData = await School.find({});
    res.json(schoolData);
  } catch (err) {
    console.error("Error fetching school data: ", err);
    res.status(500).send("Error fetching data");
  }
});





export default router;

