import express from 'express';
import Evaluator from '../models/Evaluator.js';
import { authenticateToken, isAdmin } from '../middleware/auth.js';
import { transporter } from '../config/email.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import School from '../models/School.js'
import mongoose from 'mongoose';

const router = express.Router();



router.post('/register', async (req, res) => {
  try {
    const { username, email, password, name, evaluationStage, expertise } = req.body;
    console.log('Incoming Body:', req.body);


    const existingEvaluator = await Evaluator.findOne({
      $or: [{ email }, { username }]
    });

    if (existingEvaluator) {
      return res.status(400).json({
        message: 'An account with this email or username already exists'
      });
    }

    const stageMap = {
      'Stage 1': 'stage1',
      'Stage 2': 'stage2',
      'Stage 3': 'stage3'

    };


    const evaluator = new Evaluator({
      username,
      email,
      password,
      name,
      evaluationStage: stageMap[evaluationStage] || evaluationStage,
      expertise
    });
    await evaluator.save();

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: 'jeromesaleth2000@gmail.com',
      subject: 'New Evaluator Registration',
      html: `
        <h2>New Evaluator Registration</h2>
        <p>Name: ${name}</p>
        <p>Email: ${email}</p>
        <p>Evaluation Stage: ${evaluationStage}</p>
        <p>Please review this registration in the admin dashboard.</p>
      `
    });

    res.status(201).json({
      message: 'Registration successful. Please wait for admin approval.'
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});






router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const evaluator = await Evaluator.findOne({ username });

    if (!evaluator) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    if (evaluator.status === 'pending') {
      return res.status(403).json({ message: 'Your account is pending approval' });
    }

    if (evaluator.status === 'rejected') {
      return res.status(403).json({ message: 'Your registration was not approved' });
    }

    const isMatch = await bcrypt.compare(password, evaluator.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: evaluator._id, role: 'evaluator' },
      process.env.JWT_SECRET,
      { expiresIn: '1d' }
    );

    res.json({
      token,
      evaluator: {
        id: evaluator._id,
        username: evaluator.username,
        name: evaluator.name,
        email: evaluator.email,
        evaluationStage: evaluator.evaluationStage  // default fallback
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});



// Admin routes for managing evaluators
router.get('/pending', authenticateToken, isAdmin, async (req, res) => {
  try {
    const pendingEvaluators = await Evaluator.find({ status: 'pending' });
    res.json(pendingEvaluators);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/approved/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const evaluator = await Evaluator.findById(req.params.id);
    if (!evaluator) {
      return res.status(404).json({ message: 'Evaluator not found' });
    }

    evaluator.status = 'approved';
    await evaluator.save();

    // Send approval email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: evaluator.email,
      subject: 'Evaluator Registration Approved',
      html: `
        <h2>Registration Approved</h2>
        <p>Dear ${evaluator.name},</p>
        <p>Your registration as an evaluator has been approved. You can now log in to your account.</p>
      `
    });

    res.json({ message: 'Evaluator approved successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/rejected/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const evaluator = await Evaluator.findById(req.params.id);
    if (!evaluator) {
      return res.status(404).json({ message: 'Evaluator not found' });
    }

    evaluator.status = 'rejected';
    await evaluator.save();

    // Send rejection email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: evaluator.email,
      subject: 'Evaluator Registration Status',
      html: `
        <h2>Registration Update</h2>
        <p>Dear ${evaluator.name},</p>
        <p>We regret to inform you that your registration as an evaluator has not been approved at this time.</p>
      `
    });

    res.json({ message: 'Evaluator rejected successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});



// router.get('/assigned-projects', authenticateToken, async (req, res) => {
//   try {
//     const evaluator = await Evaluator.findById(req.user.id);

//     if (!evaluator || evaluator.status !== 'approved') {
//       return res.status(403).json({ message: 'Unauthorized. Only approved evaluators can view projects.' });
//     }

//     // Get all approved evaluators for round-robin distribution
//     const approvedEvaluators = await Evaluator.find({ status: 'approved' });
//     const evaluatorIndex = approvedEvaluators.findIndex(e => e._id.toString() === evaluator._id.toString());

//     // Get all schools with submissions
//     const schools = await School.find({ 'submissions': { $exists: true, $not: { $size: 0 } } });

//     // Flatten and filter un-evaluated submissions
//     const allUnEvaluatedProjects = schools.flatMap(school =>
//       school.submissions
//         .filter(sub =>
//           sub.paymentStatus === 'successful' &&
//           sub.evaluationStatus === 'pending'
//         ) // ✅ Only un-evaluated ones
//         .map(sub => ({
//           ...sub.toObject(),
//           schoolName: school.School_Name,
//           udiseCode: school.UDISE_Code,
//           schoolId: school._id
//         }))
//     );

//     // Apply round-robin on un-evaluated projects only
//     const assignedProjects = allUnEvaluatedProjects.filter((_, index) =>
//       index % approvedEvaluators.length === evaluatorIndex
//     );

//     res.json(assignedProjects);
//   } catch (error) {
//     console.error('Error fetching assigned projects:', error);
//     res.status(500).json({ message: 'Server error' });
//   }
// });




// Submit evaluation for a project

// router.get('/assigned-projects', authenticateToken, async (req, res) => {
//   try {
//     // Step 1: Get the current evaluator
//     const evaluator = await Evaluator.findById(req.user.id);
//     if (!evaluator || evaluator.status !== 'approved' || evaluator.evaluationStage !== 'stage1') {
//       return res.status(403).json({
//         message: 'Unauthorized. Only approved Stage 1 evaluators can view projects.'
//       });
//     }

//     // Step 2: Get all approved stage1 evaluators
//     const stage1Evaluators = await Evaluator.find({ status: 'approved', evaluationStage: 'stage1' });

//     // Step 3: Find the current evaluator's index in the list
//     const evaluatorIndex = stage1Evaluators.findIndex(
//       e => e._id.toString() === evaluator._id.toString()
//     );

//     // Step 4: Get all schools with valid submissions (successful payment, pending evaluation)
//     const schools = await School.find({
//       submissions: { $exists: true, $not: { $size: 0 } }
//     });

//     // Step 5: Flatten and filter all pending submissions (successful payment + pending evaluation)
//     const allPendingProjects = [];

//     schools.forEach(school => {
//       school.submissions.forEach(sub => {
//         if (sub.paymentStatus === 'successful' && sub.evaluationStatus === 'pending') {
//           allPendingProjects.push({
//             ...sub.toObject(),
//             schoolName: school.School_Name,
//             udiseCode: school.UDISE_Code,
//             schoolId: school._id
//           });
//         }
//       });
//     });

//     // Step 6: Round-robin distribution of projects across all evaluators
//     const assignedProjects = allPendingProjects.filter((_, index) => {
//       // Use modulo to assign projects evenly
//       return index % stage1Evaluators.length === evaluatorIndex;
//     });

//     // Step 7: Send the assigned projects to the evaluator
//     res.json(assignedProjects);

//   } catch (error) {
//     console.error('Error fetching assigned projects:', error);
//     res.status(500).json({ message: 'Internal Server Error' });
//   }
// });

router.get('/assigned-projects', authenticateToken, async (req, res) => {
  try {
    // Step 1: Get the current evaluator
    const evaluator = await Evaluator.findById(req.user.id);
    if (!evaluator || evaluator.status !== 'approved' || evaluator.evaluationStage !== 'stage1') {
      return res.status(403).json({
        message: 'Unauthorized. Only approved Stage 1 evaluators can view projects.'
      });
    }

    // Step 2: Get all approved stage1 evaluators
    const stage1Evaluators = await Evaluator.find({ status: 'approved', evaluationStage: 'stage1' });

    // Step 3: Get all schools with valid submissions
    const schools = await School.find({
      submissions: { $exists: true, $not: { $size: 0 } }
    });

    const submissionsToUpdate = []; // to track if any updates are needed
    let allPendingProjects = [];

    // Step 4: Go through all submissions
    schools.forEach((school) => {
      school.submissions.forEach((sub, i) => {
        // Check if submission is valid
        if (sub.paymentStatus === 'successful' && sub.evaluationStatus === 'pending') {
          // If not yet assigned, assign in round-robin
          if (!sub.assignedEvaluatorId) {
            const index = allPendingProjects.length;
            const assignedEvaluator = stage1Evaluators[index % stage1Evaluators.length];
            sub.assignedEvaluatorId = assignedEvaluator._id;
            submissionsToUpdate.push(school); // mark for saving
          }

          allPendingProjects.push({
            ...sub.toObject(),
            schoolName: school.School_Name,
            udiseCode: school.UDISE_Code,
            schoolId: school._id
          });
        }
      });
    });

    // Save updated submissions (only schools that had unassigned projects)
    await Promise.all(submissionsToUpdate.map(school => school.save()));

    // Step 5: Filter only projects assigned to current evaluator and still pending
    const assignedProjects = allPendingProjects.filter(
      (proj) => proj.assignedEvaluatorId?.toString() === evaluator._id.toString()
    );

    // Step 6: Send response
    res.json(assignedProjects);

  } catch (error) {
    console.error('Error fetching assigned projects:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});



// Handle evaluation submission to update evaluation status
router.post('/evaluate-project', authenticateToken, async (req, res) => {
  try {
    const { projectId, evaluationStatus, evaluatorComments } = req.body;

    // Step 1: Get current evaluator
    const evaluator = await Evaluator.findById(req.user.id);
    if (!evaluator || evaluator.status !== 'approved' || evaluator.evaluationStage !== 'stage1') {
      return res.status(403).json({
        message: 'Unauthorized. Only approved Stage 1 evaluators can evaluate projects.'
      });
    }

    // Step 2: Find the project and mark it as evaluated
    const school = await School.findOne({ 'submissions._id': projectId });
    if (!school) {
      return res.status(404).json({ message: 'Project not found.' });
    }

    const project = school.submissions.id(projectId);

    // Step 3: Only allow updating if the project is still pending evaluation
    if (project.evaluationStatus !== 'pending') {
      return res.status(400).json({ message: 'This project has already been evaluated.' });
    }

    // Step 4: Update the evaluation status and evaluator's comments
    project.evaluationStatus = evaluationStatus;
    project.evaluatorComments = evaluatorComments;

    // Step 5: Save the changes
    await school.save();

    // Step 6: Return the success message
    res.json({ message: 'Project evaluated successfully.' });

  } catch (error) {
    console.error('Error submitting evaluation:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});







router.post('/evaluate/:projectId', authenticateToken, async (req, res) => {
  try {
    const { projectId } = req.params;
    const { status, reason } = req.body;
    const evaluatorId = req.user.id;

    // Fetch evaluator
    const evaluator = await Evaluator.findById(evaluatorId);
    if (!evaluator || evaluator.status !== 'approved') {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    // Find school and submission
    const school = await School.findOne({ 'submissions._id': projectId });
    if (!school) return res.status(404).json({ message: 'Project not found' });

    const submission = school.submissions.id(projectId);
    if (!submission) return res.status(404).json({ message: 'Submission not found' });

    // Only initialize evaluator slots if they don't exist
    if (!submission.evaluationScores || submission.evaluationScores.length === 0) {
      for (let i = 1; i <= 3; i++) {
        submission.evaluationScores.push({
          evaluatorNumber: i,
          evaluatorName: '',
          score: 0,
          status: 'Pending',
          evaluatedAt: new Date(),
        });
      }
    }

    // Save evaluation data
    submission.evaluationStatus = status;
    submission.statusReason = reason;
    submission.evaluatedBy = {
      id: evaluator._id,
      name: evaluator.name,
      email: evaluator.email,
      phone: evaluator.phone,
      organization: evaluator.organization,
    };
    submission.evaluatedAt = new Date();

    await school.save();

    res.json({ message: 'Evaluation submitted successfully' });
  } catch (error) {
    console.error('Error submitting evaluation:', error);
    res.status(500).json({ message: 'Server error' });
  }
});






router.get('/accepted-projects', async (req, res) => {
  try {
    const schools = await School.aggregate([
      { $unwind: "$submissions" },
      { $match: { "submissions.evaluationStatus": "accepted" } },
      {
        $project: {
          schoolId: "$UDISE_Code",
          schoolName: "$School_Name",
          projectId: "$submissions._id",
          title: "$submissions.projectDetails.title",
          description: "$submissions.projectDetails.description",
          evaluationStatus: "$submissions.evaluationStatus",
         documentFile: "$submissions.documentFile", // ✅ corrected here
          evaluationScores: "$submissions.evaluationScores", // ✅ Include scores here
        }
      },
    ]);

    res.json(schools);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch accepted projects' });
  }
});


router.post('/submit-score', authenticateToken, async (req, res) => {
  const { projectId, evaluatorName, score, status } = req.body;

  try {
    const school = await School.findOne({
      "submissions._id": projectId,
    });

    if (!school) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const submission = school.submissions.find(sub => sub._id.toString() === projectId);
    if (!submission) {
      return res.status(404).json({ error: 'Submission not found' });
    }

    // Find first available evaluator slot
    const slot = submission.evaluationScores.find(e => !e.evaluatorName || e.status === 'Pending');

    if (!slot) {
      return res.status(400).json({ error: 'All evaluator slots are already filled' });
    }

    // Update slot
    slot.evaluatorName = evaluatorName;
    slot.score = score;
    slot.status = status;
    slot.evaluatedAt = new Date();

    await school.save();

    res.status(200).json({ message: 'Score submitted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error submitting score' });
  }
});




// // Endpoint to get evaluated projects and calculate average score
// router.get('/evaluated-projects/:schoolId', async (req, res) => {
//   const schoolId = req.params.schoolId;

//   try {
//     // Fetch the school document by ID
//     const school = await School.findById(schoolId);

//     if (!school) {
//       return res.status(404).json({ message: 'School not found' });
//     }

//     // Loop through all submissions and calculate average score for each
//     const submissionsWithAvgScores = school.submissions.map(submission => {
//       // Calculate the total score from evaluationScores
//       const totalScore = submission.evaluationScores.reduce((sum, evalScore) => sum + evalScore.score, 0);
//       const avgScore = submission.evaluationScores.length > 0 ? totalScore / submission.evaluationScores.length : 0; // Avoid division by 0

//       return {
//         projectDetails: submission.projectDetails,
//         evaluationScores: submission.evaluationScores,
//         averageScore: avgScore,
//         status: submission.evaluationStatus, // "Accepted" or "Rejected"
//       };
//     });

//     // Send the submissions with average scores as a response
//     res.json(submissionsWithAvgScores);
//   } catch (error) {
//     console.error('Error fetching evaluated projects:', error);
//     res.status(500).json({ message: 'Failed to fetch evaluated projects' });
//   }
// });


router.get('/evaluated-projects/:schoolId', async (req, res) => {
  const schoolId = req.params.schoolId;

  // Check if the schoolId is valid
  if (!schoolId || !mongoose.Types.ObjectId.isValid(schoolId)) {
    return res.status(400).json({ message: 'Invalid school ID' });
  }

  try {
    // Fetch the school document by ID
    const school = await School.findById(schoolId);

    if (!school) {
      return res.status(404).json({ message: 'School not found' });
    }

    // Loop through all submissions and calculate average score for each
    const submissionsWithAvgScores = school.submissions.map(submission => {
      // Calculate the total score from evaluationScores
      const totalScore = submission.evaluationScores.reduce((sum, evalScore) => sum + evalScore.score, 0);
      const avgScore = submission.evaluationScores.length > 0 ? totalScore / submission.evaluationScores.length : 0; // Avoid division by 0

      return {
        projectDetails: submission.projectDetails,
        evaluationScores: submission.evaluationScores,
        averageScore: avgScore,
        status: submission.evaluationStatus, // "Accepted" or "Rejected"
      };
    });

    // Send the submissions with average scores as a response
    res.json(submissionsWithAvgScores);
  } catch (error) {
    console.error('Error fetching evaluated projects:', error);
    res.status(500).json({ message: 'Failed to fetch evaluated projects' });
  }
});


// router.get('/getAcceptedEvaluatedProjects',async (req, res) => {
//   try {
//     const schools = await School.find();

//     // Prepare result
//     const filteredProjects = [];

//     for (const school of schools) {
//       const schoolId = school._id;

//       school.submissions.forEach((submission, index) => {
//         const { evaluationStatus, evaluationScores } = submission;

//         const allEvaluated =
//           evaluationScores.length === 3 &&
//           evaluationScores.every(score => score.status === "Evaluated");

//         if (evaluationStatus === "accepted" && allEvaluated) {
//           filteredProjects.push({
//             schoolId,
//             projectId: index + 1, // or use a real ID if you have one
//             projectTitle: submission.projectDetails.title,
//             projectDescription: submission.projectDetails.description,
//             projectDocument: submission.documentFile?.filename,
//             evaluationStatus: submission.evaluationStatus,
//             evaluationReason: submission.statusReason,
//             evaluatorScores: submission.evaluationScores,
//           });
//         }
//       });
//     }

//     return res.json({ data: filteredProjects });
//   } catch (error) {
//     console.error("Error fetching filtered submissions:", error);
//     return res.status(500).json({ message: "Internal server error" });
//   }

// });

router.get('/getAcceptedEvaluatedProjects', async (req, res) => {
  try {
    const schools = await School.find();

    const filteredProjects = [];

    for (const school of schools) {
      const schoolId = school._id;

      school.submissions.forEach((submission, index) => {
        const { evaluationStatus, evaluationScores } = submission;

        const allEvaluated =
          evaluationScores.length === 3 &&
          evaluationScores.every(score => score.status === "Evaluated");

        if (evaluationStatus === "accepted" && allEvaluated) {
          // Calculate average score
          const totalScore = evaluationScores.reduce((sum, e) => sum + (e.score || 0), 0);
          const averageScore = (totalScore / evaluationScores.length).toFixed(2);

          filteredProjects.push({
            schoolId,
            projectId: submission._id,
            district : school.District,
            projectTitle: submission.projectDetails.title,
            projectDescription: submission.projectDetails.description,
            projectDocument: submission.documentFile?.filename,
            evaluationStatus: submission.evaluationStatus,
            evaluationReason: submission.statusReason,
            evaluatorScores: submission.evaluationScores,
            averageScore: parseFloat(averageScore)
          });
        }
      });
    }

    return res.json({ data: filteredProjects });
  } catch (error) {
    console.error("Error fetching filtered submissions:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// Update school evaluation status to 'winner'
router.post('/update-winner', async (req, res) => {
    const { schoolId, projectId, status } = req.body; // include `status` from frontend: 'accept' or 'reject'

    try {
        const school = await School.findOne({ _id: schoolId });

        if (!school) return res.status(404).json({ success: false, message: 'School not found' });

        const submission = school.submissions.id(projectId);

        if (!submission) return res.status(404).json({ success: false, message: 'Project not found' });

        // Update evaluation status based on input
        if (status === 'accept') {
            submission.evaluationStatus = 'winner';
        } else if (status === 'reject') {
            submission.evaluationStatus = 'runner';
        } else {
            return res.status(400).json({ success: false, message: 'Invalid status' });
        }

        await school.save();

        return res.json({ success: true, message: 'Status updated successfully' });
    } catch (err) {
        console.error('Error updating evaluation status:', err);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
});


export default router;