// Admin login route (Node.js backend)
import jwt from 'jsonwebtoken';
import express from 'express';
import School from '../models/School.js'
import Evaluator from '../models/Evaluator.js';

const router = express.Router();

router.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Simple check (replace with DB check in real apps)
  if (username === 'admin' && password === 'admin123') {
    const token = jwt.sign(
      { username, role: 'admin' },
      process.env.JWT_SECRET || 'vosa',
      { expiresIn: '1h' }
    );

    res.json({ token });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});


// // GET /api/dashboard/summary
// router.get('/summary', async (req, res) => {
//   try {
//     const schools = await School.find();

//     // Total registered schools
//     const totalSchools = schools.length;

//     // Total guide teachers
//     const totalGuideTeachers = schools.reduce((acc, school) => acc + school.guideTeachers.length, 0);

//     // Total submissions
//     let totalSubmissions = 0;
//     let acceptedSubmissions = 0;
//     let rejectedSubmissions = 0;
//     let pendingPayments = 0;
//     let successfulPayments = 0;
//     let failedPayments = 0;

//     schools.forEach(school => {
//       totalSubmissions += school.submissions.length;

//       school.submissions.forEach(sub => {
//         // Payment status count
//         if (sub.paymentStatus === 'pending') pendingPayments++;
//         if (sub.paymentStatus === 'successful') successfulPayments++;
//         if (sub.paymentStatus === 'failed') failedPayments++;

//         // Evaluation status count
//         if (sub.evaluationStatus === 'Accepted') acceptedSubmissions++;
//         if (sub.evaluationStatus === 'Rejected') rejectedSubmissions++;
//       });
//     });

//     return res.json({
//       totalSchools,
//       totalGuideTeachers,
//       totalSubmissions,
//       acceptedSubmissions,
//       rejectedSubmissions,
//       paymentStatus: {
//         pending: pendingPayments,
//         successful: successfulPayments,
//         failed: failedPayments
//       }
//     });

//   } catch (error) {
//     console.error("Dashboard Summary Error:", error);
//     res.status(500).json({ message: 'Server Error' });
//   }
// });
// router.get('/summary/:schoolId', async (req, res) => {
//   try {
//     const school = await School.findById(req.params.schoolId);
//     if (!school) return res.status(404).json({ message: 'School not found' });

//     const totalProjects = school.submissions.length;
//     const guideTeachers = school.guideTeachers.length;
//     const teamsCount = school.submissions.reduce((sum, sub) => sum + (sub.students?.length || 0), 0);

//     res.json({
//       totalProjects,
//       guideTeachers,
//       teamsCount
//     });

//   } catch (err) {
//     console.error("School Summary Error:", err);
//     res.status(500).json({ message: 'Server Error' });
//   }
// });
// router.get('/summary/:schoolId', async (req, res) => {
//   try {
//     const school = await School.findById(req.params.schoolId);
//     if (!school) return res.status(404).json({ message: 'School not found' });

//     const totalProjects = school.submissions.length;
//     const guideTeachers = school.guideTeachers.length;

//     // Each submission is one team
//     const teamsCount = totalProjects;

//     // Count total students in all submissions
//     const studentsCount = school.submissions.reduce((sum, sub) => {
//       return sum + (sub.students?.length || 0);
//     }, 0);

//     res.json({
//       totalProjects,
//       guideTeachers,
//       teamsCount,
//       studentsCount
//     });

//   } catch (err) {
//     console.error("School Summary Error:", err);
//     res.status(500).json({ message: 'Server Error' });
//   }
// });
// router.get('/summary/:schoolId', async (req, res) => {
//   try {
//     const school = await School.findById(req.params.schoolId);
//     if (!school) return res.status(404).json({ message: 'School not found' });

//     const submissions = school.submissions;

//     const totalProjects = submissions.length;
//     const guideTeachers = school.guideTeachers.length;
//     const teamsCount = totalProjects;

//     const studentsList = submissions.flatMap(sub => sub.studentDetails || []);
//     const studentsCount = studentsList.length;

//     const guideTeachersList = school.guideTeachers;

//     // Pending = no evaluationStatus OR it's not "Accepted"/"Rejected"
//     const pendingProjects = submissions.filter(sub => !['Accepted', 'Rejected'].includes(sub.evaluationStatus));
//     const completedProjects = submissions.filter(sub => ['Accepted', 'Rejected'].includes(sub.evaluationStatus));

//     res.json({
//       totalProjects,
//       guideTeachers,
//       teamsCount,
//       studentsCount,
//       guideTeachersList,
//       studentDetailsList: studentsList,
//       pendingProjectsList: pendingProjects,
//       completedProjectsList: completedProjects
//     });

//   } catch (err) {
//     console.error("School Summary Error:", err);
//     res.status(500).json({ message: 'Server Error' });
//   }
// });
router.get('/summary/:schoolId', async (req, res) => {
  try {
    const school = await School.findById(req.params.schoolId);
    if (!school) return res.status(404).json({ message: 'School not found' });

    const submissions = school.submissions || [];

    const totalProjects = submissions.length;
    const guideTeachers = school.guideTeachers.length;
    const teamsCount = totalProjects;

    const studentsList = submissions.flatMap(sub => sub.studentDetails || []);
    const studentsCount = studentsList.length;

    const guideTeachersList = school.guideTeachers;

    const pendingProjects = submissions.filter(sub =>
      !['Accepted', 'Rejected'].includes(sub.evaluationStatus)
    );

    const completedProjects = submissions
      .filter(sub =>
        sub.paymentStatus === 'successful' &&
        sub.evaluationStatus?.toLowerCase() === 'accepted'
      )
      .map(sub => ({
        projectDetails: sub.projectDetails,
        bmcDetails: sub.bmcDetails,
        paymentStatus: sub.paymentStatus,
        evaluationScores: sub.evaluationScores,
        evaluatedBy: sub.evaluatedBy,
        documentFile: sub.documentFile?.data ? {
          filename: sub.documentFile.filename,
          contentType: sub.documentFile.contentType,
          base64: sub.documentFile.data.toString('base64')
        } : null,
        paymentScreenshot: sub.paymentScreenshot?.data ? {
          filename: sub.paymentScreenshot.filename,
          contentType: sub.paymentScreenshot.contentType,
          base64: sub.paymentScreenshot.data.toString('base64')
        } : null
      }));


    res.json({
      totalProjects,
      guideTeachers,
      teamsCount,
      studentsCount,
      guideTeachersList,
      studentDetailsList: studentsList,
      pendingProjectsList: pendingProjects,
      completedProjectsList: completedProjects
    });

  } catch (err) {
    console.error("School Summary Error:", err);
    res.status(500).json({ message: 'Server Error' });
  }
});


// GET all evaluators
router.get('/get-evaluators', async (req, res) => {
  try {
    const evaluators = await Evaluator.find({}, '-password'); // exclude password
    res.json(evaluators);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch evaluators' });
  }
});

// Get all registered schools
router.get('/get-registered-schools', async (req, res) => {
  try {
    // Assuming you have a "status" field to check if the school is registered
    const registeredSchools = await School.find({ status: 'registered' }); // Fetch all schools with 'registered' status
    res.json(registeredSchools); // Send the registered school data as JSON response
  } catch (error) {
    res.status(500).send({ error: 'Failed to fetch registered school data' });
  }
});

export default router;
